<?php
class Common_model extends CI_Model {
        public $table= 'genres';
        public $key= 'id';
        function __construct() {
                
                
        }
        public function getimg($id)
        {
            $row = $this->db->where('mediaID',$id)->get('media')->row();
            if($row)
            {
                $url = base_url().$row->localPath; 
                return $url;
            } 
            return base_url('/default .jpg');
        }
        
        public function get($data)
        {

            $this->db->order_by($this->key, "asc");
                if(!$data)
                {
                        return $this->db->get($this->table)->result_array();
                }
                else
                {
                        return $this->db->where($data)->get($this->table)->result_array();
                }
        }
        public function getMediaByID($mediaID)
        {

             $row= $this->db->where('mediaID', $mediaID)->get('media')->row();
            if($row)
            {

                    return $row;
            }   
        }
        public function update($genreID, $data)
        {
                return $this->db->where($this->key, $genreID)->update($this->table, $data);
        }
        public function delete($tagID)
        {
                return $this->db->where('tagID', $tagID)->delete();
        }
        public function add($data)
        {
                $this->db->insert($this->table,$data);
				//echo $sql = $this->db->last_query();
                return $this->db->insert_id();

        }
        public function addMedia($ar)
        {
            
            $this->db->insert('media', $ar);
            return $this->db->insert_id();

        }
        public function login($uname, $upass)
        {
                $upass = md5($upass);
                $sql = "select * from `users` WHERE email = '$uname'  OR `uname` = '$uname' AND `upass` = '$upass'";
 
                $query = $this->db->query($sql);
                return $query->row();
        }
        public function updateuserbyid($userID, $data)
        {
                return $this->db->where('UserID',$userID)->update('users');

        }
        public function getbyid($userID)
        {
                return $this->db->where($this->key,$userID)->get($this->table)->row();

        }
        public function getrolebyid($roleID)
        {
                
 
                $query = $this->db->get('roles');
                return $query->row();
        }

        public function insert_entry()
        {
                $this->title    = $_POST['title']; // please read the below note
                $this->content  = $_POST['content'];
                $this->date     = time();

                $this->db->insert('entries', $this);
        }


         public function get_tag($data)
        {
                if(!$data)
                {
                        return $this->db->get('tags')->result_array();
                }
                else
                {
                        return $this->db->where($data)->get('tags')->result_array();
                }
        }

        

}