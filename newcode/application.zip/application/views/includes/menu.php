
				<ul class="menu">
					<li class="active"><a href="<?= base_url('//index/page/home'); ?>">HOME</a></li>
					<li><a href="#">NUTRITION PLAN</a></li>
					<li><a href="<?= base_url('//index/page/shop'); ?>">SHOP</a></li>
					<li><a href="#">CART</a></li>
					<li><a href="<?= base_url('//index/page/aboutUs'); ?>">ABOUT US</a></li>
					<li><a href="<?= base_url('//index/page/myaccount'); ?>">MY ACCOUNT</a></li>
					<li><a href="<?= base_url('//index/page/after-lessons'); ?>">After Lessons</a></li>
					<li><a href="<?= base_url('//index/page/checkout'); ?>">Checkout</a></li>
					<li><a href="<?= base_url('//index/page/lessons'); ?>">Lessons</a></li>
					<li><a href="<?= base_url('//index/page/OrderSuccesful'); ?>">Order Succesful</a></li>
					<li><a href="<?= base_url('//index/page/OrderUnSuccesful'); ?>">Order UnSuccesful</a></li>
					<li><a href="<?= base_url('//index/page/Overview'); ?>">Overview</a></li>
					<li><a href="<?= base_url('//index/page/login'); ?>">Login</a></li>
					<li><a href="<?= base_url('//index/page/sign-up'); ?>">Sign Up</a></li>
					<li><a href="#">LOGOUT</a></li>
				</ul>