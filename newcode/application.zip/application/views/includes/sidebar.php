<!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="../../../html/ltr/vertical-menu-template/index.html">
                    <?php
                $user = $this->session->userdata('knet_login');
        ?>
        <img src="<?= base_url('assets/front/images/logo.png'); ?>" style="width: 78%;margin: 13px auto;" />
                    </a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
        
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li><a href="<?= base_url('admin/module/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Modules</span></a>
                        </li>
                <li><a href="<?= base_url('admin/quiz/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Quiz</span></a>
                        </li>
                <li><a href="<?= base_url('admin/question/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Question</span></a>
                        </li>
                <li><a href="<?= base_url('admin/lesson/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Lesson</span></a>
                        </li>
                <li><a href="<?= base_url('admin/course/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Courses</span></a>
                <li><a href="<?= base_url('admin/slider/all');?>"><i class="feather icon-circle"></i><span
                 class="menu-item" data-i18n="Details">Slider</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/order/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Orders</span></a>
                        </li>
                <li><a href="<?= base_url('admin/badge/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage  Badges</span></a>
                        </li>
                
            </ul>
        </div>
    </div>