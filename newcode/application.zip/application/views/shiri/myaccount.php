
	<div class="maincontents">
		<section id="banner">
			<img src="<?= $assets ?>images/pic65.png">
			<div class="banText">
				<h2>ALL YOUR DETAILS</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. </p>
			</div>
		</section>
		<div class="container">
			<div class="myAccount">
				<div class="row">
					<div class="col-md-5 col-sm-7">
						<div class="profilePic">
							<img src="<?= $assets ?>images/pic9.png">
						</div>
					</div>
					<div class="col-md-7 col-sm-7">
						<div class="profileContent">
							<h3>SHIREEN AL MUTAWA</h3>
							<label>SHIREENALMUTAWA@GMAIL.COM</label>
							<p></p>
							<p>LEVEL: FORCE FOR GOOD <span>4 Credits</span> </p>

							<label>VIEW LEVELS</label>
							<p>COURSE PROGRESS</p>
							<div class="progress">
							    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width:100%">
							      
							    </div><span>100% Completed</span> 
							</div>
						</div>
					</div>
				</div>
				<div class="acievementArea">
					<h4>ACHIEVEMENTS</h4>
					<ul class="achievments">
						<li><a href="#"><img src="<?= $assets ?>images/pic10.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic11.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic12.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic13.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic14.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic15.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic16.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic17.png"></a></li>
						<li><a href="#"><img src="<?= $assets ?>images/pic18.png"></a></li>
					</ul>
					<h4>COURSE JOURNEY</h4>
					<button class="accordion ">OUTLINE</button>
					<div class="panel">
					  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>
					<h4>UPDATE INFORMATION</h4>
					<button class="accordion" style="border-bottom: 1px solid #454545;">UPDATE PASSWORD</button>
					<div class="panel">
					  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>

					<button class="accordion">UPDATE EMAIL</button>
					<div class="panel">
					  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>
					
					<div class="certificateimg">
						<h4>CERTIFICATE</h4>
						<img src="<?= $assets ?>images/pic19.png">
					</div>
					<div class="addAddress">
						<strong>YOUR ADDRESSES</strong>
						<p>- Fahaheel, block 10, street 9</p>
						<a href="#">ADD AN ADDRESS</a>
					</div>
				</div>
				
			</div>
		</div>
		
	</div>