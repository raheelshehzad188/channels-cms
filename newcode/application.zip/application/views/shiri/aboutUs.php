
	<div class="maincontents">
		<section id="banner">
			<img src="<?= $assets ?>images/pic63.png">
			<div class="banText">
				<h2>ABOUT US</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. </p>
			</div>
		</section>
		<div class="aboutUs">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6">
						<div class="singleBox">
							<img src="<?= $assets ?>images/pic8a.png">
							<div class="abouttext">
								<h3>Shireen Al Mutawa</h3>
								<span>General Manager</span>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="aboutontent">
							<h3>Little About Us</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod temp<br>
							orincididunt ut labore et dolore magna aliqua.</p>	
							<a href="#">Read More</a>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
	</div>
