
	<div class="maincontents">
		<section id="banner">
			<img src="<?= $assets ?>images/pic64.png">
			<div class="banText">
				<h2>ORDER UNSUCCESSFUL</h2>
			</div>
		</section>
		<div class="aboutUs">
			<div class="container">
				<div class="row">
					<div class="congradulations">
						<img src="<?= $assets ?>images/pic68.png">
						<h3>THANKS FOR YOUR PURCHASE!</h3>
						<strong><span> ORDER NUMBER:</span> 001</strong>
						<strong><span>DATE:</span> 12TH FEBRUARY, 2021</strong>
						<strong><span>TOTAL:</span> 58.500 KD</strong>
						<strong><span>PAYMENT METHOD:</span> KNET</strong>
					</div>
				</div>
			</div>
		</div>
		
	</div>