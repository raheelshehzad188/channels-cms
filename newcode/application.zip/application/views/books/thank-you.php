<div class="maincontents thankYou">
		<div id="logo">
			<a href="home"><img src="<?= $assets; ?>images/logo.png"></a>
		</div>
		<h1>Thank You!</h1>
	</div>