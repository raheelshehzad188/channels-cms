<div class="maincontents">
		<div class="aboutUs">
			<h1>About Us</h1>
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic8.png">
						<div class="abouttext">
							<h3>Shireen Al Mutawa</h3>
							<span>General Manager</span>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6">
					<div class="aboutontent">
						<h3>Little About Us</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod temp <br>orincididunt ut labore et dolore magna aliqua.</p>	
						<a href="#">Read More</a>
					</div>
				</div>
				
			</div>
			
		</div>
		
	</div>