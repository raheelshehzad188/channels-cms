<div class="maincontents osama-hamdy">
		<h1>Dr. Osama Hamdy <img src="<?= $assets; ?>images/pic3.png"></h1>
		<div class="osama-hamdyArea ">
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic20.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Conceptual Art, Photography and Wild Life</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic23.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Lifestyle Archives - The Times to Change Your Life</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic24.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Cambridge English Exam Preparation</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic25.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Freelancing For Developers : A Complete Freelancing Course.</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic26.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Introduction to Fusion of Acoustic Guitar</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic27.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Basic Mathematics - Inroduction to Geometry</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic20.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Conceptual Art, Photography and Wild Life</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic23.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Lifestyle Archives - The Times to Change Your Life</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic24.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Cambridge English Exam Preparation</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic25.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Freelancing For Developers : A Complete Freelancing Course.</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic26.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Introduction to Fusion of Acoustic Guitar</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<div class="hamdyBox">
					<div class="hamdyimg">
						<img src="<?= $assets; ?>images/pic27.png">
						<div class="hamdyimgLayer">
							<a href="#"><img src="<?= $assets; ?>images/pic21.png"></a>
						</div>
					</div>
					<div class="hamdytext">
						<p>Basic Mathematics - Inroduction to Geometry</p>
						<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi bibendum venenatis mollis. Ut sem metus, convallis a libero vel, suscipit </span>
						<p class="price">$159.00 <img src="<?= $assets; ?>images/pic22.png"></p>
					</div>
				</div>
			</div>
		</div>
	</div>