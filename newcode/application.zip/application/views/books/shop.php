<div class="maincontents">
		<div class="shop">
			<h1>Shop</h1>
			<div class="row">
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic5.png">
						<div class="sessionholder">
							<h3>stacy</h3>
							<span>Muay Thai Trainer</span>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod </p>
							<a href="#">Schedule sessions</a>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic6.png">
						<div class="sessionholder">
							<h3>jake</h3>
							<span>Cardio Training</span>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic7.png">
						<div class="sessionholder">
							<h3>Victor</h3>
							<span>Crossfit Training</span>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic5.png">
						<div class="sessionholder">
							<h3>stacy</h3>
							<span>Muay Thai Trainer</span>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod </p>
							<a href="#">Schedule sessions</a>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic6.png">
						<div class="sessionholder">
							<h3>jake</h3>
							<span>Cardio Training</span>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic7.png">
						<div class="sessionholder">
							<h3>Victor</h3>
							<span>Crossfit Training</span>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic5.png">
						<div class="sessionholder">
							<h3>stacy</h3>
							<span>Muay Thai Trainer</span>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod </p>
							<a href="#">Schedule sessions</a>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic6.png">
						<div class="sessionholder">
							<h3>jake</h3>
							<span>Cardio Training</span>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="singleBox">
						<img src="<?= $assets; ?>images/pic7.png">
						<div class="sessionholder">
							<h3>Victor</h3>
							<span>Crossfit Training</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>